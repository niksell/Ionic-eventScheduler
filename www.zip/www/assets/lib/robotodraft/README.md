# RobotoDraft @font-face kit

I split the SASS file, so the developer can decide which fonts and styles he really needs.

## Demo
__Our repository:__ [http://fontfacekit.github.com/robotodraft](http://fontfacekit.github.com/robotodraft)

__Google Web Fonts:__ [http://fonts.googleapis.com/css?family=RobotoDraft:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en](http://fonts.googleapis.com/css?family=RobotoDraft:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en)


## Maintain your own font-face in FontFaceKit
Contact @gustavohenke if you want to maintain your own font-face in this repository.
